
jQuery(document).ready(function($) {
	$('.ui_tabs').tabs();
});

